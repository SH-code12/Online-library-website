
function SaveEdit ()
{
    var new_text = document.getElementsByName("edit_info")[0].value;

    document.getElementsByName("edit_info")[0].setAttribute('value', new_text);
}