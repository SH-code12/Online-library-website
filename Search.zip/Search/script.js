    const availableKeywords = [
        //1
        {title:'Computer Science overview',ID:'#143231',Author:'Glenn Brookshear and Dennis Brylow',
        category:'programming',photo: 'ComputerScienceOverview.jpg',
        description:'Develop a core understanding of the concepts of modern computer science Computer Science: An Overview, 13th edition, Global Edition, by J. Glenn Brookshear, and Dennis Brylow, is written for students from all backgrounds, giving you a bottom-up, concrete-to-abstract foundation in the subject. Its broad coverage encourages a practical and realistic understanding of computer science, covering all the major concepts.'
        },

        //2
        {title:'Python for everybody',ID:'#167231',Author:'Charles Severance',
        category:'programming languages',photo: 'Python.jpg',
        description:'Learn to Program and Analyze Data with Python. Develop programs to gather, clean, analyze, and visualize data.'
        },

        //3
        {title:'Java programming',ID:'#168941',Author:'K.somasundaram',
        category:'programming languages',photo: 'Java.jpg',
        description:'This book is intended for a one-semester, beginner’s level course on Java programming. It includes the new features included in JDK1.7. Each of its 16 chapters provide review questions for the readers to self-test their learning. “Try It Out” programs that enable the readers to develop programs for real life problems have also been included.'
        },

        //4
        {title:'Advanced JavaScript',ID:'#1228231',Author:'Zakary Shute',
        category:'programming languages',photo: 'JavaScript.jpg',
        description:'Gain a deeper understanding of JavaScript and apply it to build small applications in backend, frontend, and mobile frameworks.'
        },

        //5
        {title:'PHP and my SQL web development',ID:'#318231',Author:'Luke Welling and Laura Thomson',
        category:'Web development',photo:'PHP.jpg',
        description:'PHP and MySQL Web Development by Luke Welling and Laura Thomson is a concise guideteaching how to create dynamic websites using PHP and MySQL. Its an essential resource forbeginners and intermediate developers, offering clear explanations and practical examples.'
        },

        //6
        {title:'Full Stack Development with MongoDB',ID:'#168231',Author:'MANU SHARMA',
        category:'Web development',photo:'FullStack development.jpg',
        description:'Full Stack Development with MongoDB" is a concise guide to mastering MEAN stac development, offering clear explanations and practical examples for building dynamic web applications.'
        }
    ];

    const AvailableKeywords = JSON.stringify(availableKeywords);
    localStorage.setItem('keywords',AvailableKeywords);
    const StoredBooks = JSON.parse(localStorage.getItem('keywords'));


    const resultBox = document.querySelector(".result-box");
    const inputBox = document.querySelector("#input-box");
    const detailsBox = document.querySelector(".book-details");

    let result = [];
    inputBox.addEventListener('input', function(){
        let input = inputBox.value;
        if(input === ''){
            resultBox.innerHTML = '';
            return;
        }
        if(input.length > 0){
            result = StoredBooks.filter((keyword)=>{
                return keyword.title.toLowerCase().includes(input.toLowerCase()) ||
                keyword.Author.toLowerCase().includes(input.toLowerCase()) ||
                keyword.category.toLowerCase().includes(input.toLowerCase()) ;
            });
            console.log(result);
        }
        if(result.length > 0){
            display(result); 
        }
        else{
            resultBox.innerHTML = '';
        }
    });

    function display(result){
        const content = result.map(list => {return ("<li onclick=selectInput(this)>" + list.title + "</li>" +
        "<li onclick=selectInput(this)>" + list.Author + "</li>" +
        "<li onclick=selectInput(this)>" + list.category + "</li>");});
        resultBox.innerHTML = "<ul>" + content.join("") + "</ul>";
    }

    function selectInput(list){
        inputBox.value = list.textContent;
        resultBox.innerHTML = '';
    }
    detailsBox.addEventListener('click',function(){
        const details = result.find((item) => item.title === inputBox.value);
        
        detailsBox.innerHTML = details.photo + "<br>" +details.title; 
    });
