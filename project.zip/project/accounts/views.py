from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import UserChangeForm
from django.shortcuts import redirect,render
from .models import account
from django.db import connection
from pages.views import homeuser,homeadmin,account_admin,account_user
from .forms import profile


def home(request):
    return render(request,'registration/home.html')
    # home = loader.get_template('registration/home.html')
    # return HttpResponse(home)
    
def login(request):
    if request.method=="POST":
        name = request.POST.get('usern')
        password = request.POST.get('pass')
        for x in account.objects.all() :
            if x.Username == name:
                if x.Password ==password:
                    data = account(Username=name,Password=password,Email=x.Email,Admin=x.Admin,User=x.User)
                    if x.User:
                        return render(request,'registration/view_user.html',{'accounts':data})
                    elif x.Admin:
                        return render(request,'registration/view_admin.html',{'accounts':data})  
                   
    return render(request,'registration/login.html')  


def signup(request):
    dataform=profile(request.POST)
    if dataform.is_valid():
        if request.method=="POST":
            name = request.POST.get('usern')
            password = request.POST.get('pass')
            confirm_password = request.POST.get('conpass')
            email = request.POST.get('e')
            types=request.POST.get('userType')
            if password==confirm_password:
                if types=="admin":
                    data = account(Username=name,Password=password,Email=email,Admin=1,User=0)
                    data.save()
                    return render(request,'registration/view_admin.html',{'accounts':data})
                elif types=="user":
                    data = account(Username=name,Password=password,Email=email,Admin=0,User=1)
                    data.save()
                    return render(request,'registration/view_user.html',{'accounts':data})
                
    return render(request,'registration/signup.html',{'form',profile}) 
         
         
         
        
# def account_list(request):
#     return render(request,'registration/account.html',{'accounts':account.objects.all()})

# def accounts(request):
#     return render(request,'registration/accounts.html',{'accounts':account.objects.all()})
