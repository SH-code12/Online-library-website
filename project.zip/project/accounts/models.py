from django.db import models
from datetime import datetime
# from django.contrib.auth.models import User


class account(models.Model):
    Username = models.CharField(max_length=50)
    Password = models.CharField(max_length=20)
    Email    = models.EmailField()
    Admin    = models.BooleanField(default=False) 
    User     = models.BooleanField(default=False)

    def __str__(self):
        return self.Username
    
    class Meta:
        verbose_name='User'
        ordering =['Username']
        
        
          
    

        
    