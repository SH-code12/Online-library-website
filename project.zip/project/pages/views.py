from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import UserChangeForm
from django.shortcuts import redirect,render
from accounts.models import account
from django.db import connection


def homeuser(request):
    return render(request,'registration/view_user.html',)

def homeadmin(request):
    return render(request,'registration/view_admin.html',)

def account_user(request):
    return render(request,'registration/account_user.html',)

def account_admin(request):
    return render(request,'registration/account_admin.html',)




# def test(request):
#     print(request.method)
#     name = request.GET.get('usern')
#     print(name)
#     return render(request,'registration/test.html')  

# def t(request):
#      print(request.method)
#      name = request.POST.get('usern')
#      print(name)
#      return render(request,'registration/t.html')  