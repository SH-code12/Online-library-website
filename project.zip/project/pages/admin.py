from django.contrib import admin
from accounts.models import account
# Register your models here.

# admin.site.register(account)
