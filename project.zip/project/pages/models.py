from django.contrib import admin
from accounts.models import account
# Register your models here.

