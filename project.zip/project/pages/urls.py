from django.urls import path
from . import views

urlpatterns = [
    
     path('Home_User/',  views.homeuser     ,name='homeuser'),
     path('Home_Admin/', views.homeadmin    ,name='homeadmin'),
     path('account_user/',views.account_user,name='auser'),
     path('account_admin/',views.account_admin,name='aadmin'),
    
    
]